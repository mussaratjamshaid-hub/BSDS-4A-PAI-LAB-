const dropBox = document.getElementById('dropBox');
const fileInput = document.getElementById('fileInput');
if (dropBox && fileInput) {
  dropBox.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropBox.classList.add('dragover');
  });
  dropBox.addEventListener('dragleave', (e) => {
    e.preventDefault();
    dropBox.classList.remove('dragover');
  });
  dropBox.addEventListener('drop', (e) => {
    e.preventDefault();
    dropBox.classList.remove('dragover');
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
    }
  });
  dropBox.addEventListener('click', () => fileInput.click());
}
