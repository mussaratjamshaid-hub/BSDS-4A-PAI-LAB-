from flask import Flask, render_template, request, jsonify
import requests
from datetime import datetime

app = Flask(__name__)

# OpenWeatherMap API (free tier)
API_KEY = "b6fd43953d59a45c12fdb80f02f2a0f1"  # Free tier API key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"
FORECAST_URL = "https://api.openweathermap.org/data/2.5/forecast"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/weather', methods=['GET'])
def get_weather():
    """Get current weather data for a city"""
    city = request.args.get('city', 'London')
    
    if not city:
        return jsonify({'error': 'City parameter is required'}), 400
    
    try:
        params = {
            'q': city,
            'appid': API_KEY,
            'units': 'metric'  # Use Celsius
        }
        
        response = requests.get(BASE_URL, params=params)
        
        if response.status_code == 404:
            return jsonify({'error': f'City "{city}" not found'}), 404
        
        if response.status_code != 200:
            return jsonify({'error': 'Unable to fetch weather data'}), 500
        
        data = response.json()
        
        weather_info = {
            'city': data['name'],
            'country': data['sys']['country'],
            'temperature': data['main']['temp'],
            'temp_min': data['main']['temp_min'],
            'temp_max': data['main']['temp_max'],
            'feels_like': data['main']['feels_like'],
            'humidity': data['main']['humidity'],
            'pressure': data['main']['pressure'],
            'description': data['weather'][0]['description'].title(),
            'icon': data['weather'][0]['icon'],
            'wind_speed': data['wind']['speed'],
            'clouds': data['clouds']['all'],
            'sunrise': datetime.fromtimestamp(data['sys']['sunrise']).strftime('%H:%M:%S'),
            'sunset': datetime.fromtimestamp(data['sys']['sunset']).strftime('%H:%M:%S'),
            'timezone': data['timezone'],
            'coordinates': {
                'lat': data['coord']['lat'],
                'lon': data['coord']['lon']
            }
        }
        
        return jsonify(weather_info)
    
    except requests.exceptions.RequestException as e:
        return jsonify({'error': 'Network error occurred'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/forecast', methods=['GET'])
def get_forecast():
    """Get 5-day weather forecast for a city"""
    city = request.args.get('city', 'London')
    
    if not city:
        return jsonify({'error': 'City parameter is required'}), 400
    
    try:
        params = {
            'q': city,
            'appid': API_KEY,
            'units': 'metric'
        }
        
        response = requests.get(FORECAST_URL, params=params)
        
        if response.status_code == 404:
            return jsonify({'error': f'City "{city}" not found'}), 404
        
        if response.status_code != 200:
            return jsonify({'error': 'Unable to fetch forecast data'}), 500
        
        data = response.json()
        
        forecasts = []
        for item in data['list'][::8]:  # Get every 8th item (one per day)
            forecast = {
                'date': datetime.fromtimestamp(item['dt']).strftime('%Y-%m-%d %H:%M:%S'),
                'temperature': item['main']['temp'],
                'temp_min': item['main']['temp_min'],
                'temp_max': item['main']['temp_max'],
                'description': item['weather'][0]['description'].title(),
                'icon': item['weather'][0]['icon'],
                'humidity': item['main']['humidity'],
                'wind_speed': item['wind']['speed']
            }
            forecasts.append(forecast)
        
        return jsonify({
            'city': data['city']['name'],
            'country': data['city']['country'],
            'forecast': forecasts
        })
    
    except requests.exceptions.RequestException as e:
        return jsonify({'error': 'Network error occurred'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
