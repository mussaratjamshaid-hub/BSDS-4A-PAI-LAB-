# Face Profiling (With Feature Measurements)

Simple Flask app that detects facial landmarks using dlib and OpenCV, measures features (eyes, nose, mouth, jaw), and produces an illustrative personality-style profile (based on heuristic thresholds). This is for demonstration only.

Setup

1. Create a Python environment (recommended).
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Download the dlib 68-point shape predictor:

https://github.com/davisking/dlib-models/raw/master/shape_predictor_68_face_landmarks.dat.bz2

Unpack and place `shape_predictor_68_face_landmarks.dat` in the project root, or set environment variable `DLIB_PREDICTOR_PATH` to its path.

Run

```bash
python app.py
```

Open http://127.0.0.1:5000 and upload an image.

Notes

- The personality mapping is heuristic and illustrative; it is NOT a validated psychological model.
- dlib installation can be non-trivial on Windows — see dlib docs if pip install fails.
