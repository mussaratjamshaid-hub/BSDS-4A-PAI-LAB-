from hadith_qna_app import search, df, model, index
print(search('What is the chain of narrators?', df, model, index))
