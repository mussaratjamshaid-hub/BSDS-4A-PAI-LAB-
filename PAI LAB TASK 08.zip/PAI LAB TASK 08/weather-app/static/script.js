// API endpoints
const WEATHER_API = '/api/weather';
const FORECAST_API = '/api/forecast';

// DOM elements
const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const errorMessage = document.getElementById('errorMessage');
const loadingSpinner = document.getElementById('loadingSpinner');
const currentWeatherSection = document.getElementById('currentWeather');
const forecastSection = document.getElementById('forecastSection');

// Event listeners
searchBtn.addEventListener('click', handleSearch);
cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        handleSearch();
    }
});

// Initialize with default city
window.addEventListener('load', () => {
    fetchWeather('London');
});

/**
 * Handle search button click
 */
function handleSearch() {
    const city = cityInput.value.trim();
    if (city) {
        fetchWeather(city);
    } else {
        showError('Please enter a city name');
    }
}

/**
 * Fetch weather data and display it
 */
function fetchWeather(city) {
    showLoading(true);
    hideError();

    // Fetch current weather and forecast in parallel
    Promise.all([
        fetch(`${WEATHER_API}?city=${encodeURIComponent(city)}`),
        fetch(`${FORECAST_API}?city=${encodeURIComponent(city)}`)
    ])
    .then(responses => Promise.all(responses.map(r => r.json())))
    .then(([weatherData, forecastData]) => {
        if (weatherData.error) {
            showError(weatherData.error);
            showLoading(false);
            return;
        }

        displayWeather(weatherData);
        displayForecast(forecastData);
        cityInput.value = '';
        showLoading(false);
    })
    .catch(error => {
        console.error('Error:', error);
        showError('Failed to fetch weather data. Please try again.');
        showLoading(false);
    });
}

/**
 * Display current weather information
 */
function displayWeather(data) {
    // Update header
    document.getElementById('cityName').textContent = 
        `${data.city}, ${data.country}`;
    document.getElementById('weatherDescription').textContent = 
        data.description;

    // Update main weather display
    document.getElementById('temperature').textContent = 
        `${Math.round(data.temperature)}°C`;
    document.getElementById('feelsLike').textContent = 
        `Feels like ${Math.round(data.feels_like)}°C`;

    // Update weather icon
    const iconCode = data.icon;
    const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
    document.getElementById('weatherIcon').src = iconUrl;

    // Update weather details
    document.getElementById('tempMinMax').textContent = 
        `${Math.round(data.temp_min)}°C / ${Math.round(data.temp_max)}°C`;
    document.getElementById('humidity').textContent = data.humidity;
    document.getElementById('windSpeed').textContent = data.wind_speed.toFixed(1);
    document.getElementById('pressure').textContent = data.pressure;
    document.getElementById('clouds').textContent = data.clouds;
    document.getElementById('sunrise').textContent = data.sunrise;
    document.getElementById('sunset').textContent = data.sunset;
    document.getElementById('coordinates').textContent = 
        `${data.coordinates.lat.toFixed(2)}°, ${data.coordinates.lon.toFixed(2)}°`;

    // Show weather section
    currentWeatherSection.classList.remove('hidden');

    // Update background gradient based on time of day (optional enhancement)
    updateBackgroundBasedOnWeather(iconCode);
}

/**
 * Display 5-day forecast
 */
function displayForecast(data) {
    const forecastContainer = document.getElementById('forecastContainer');
    forecastContainer.innerHTML = '';

    data.forecast.forEach(day => {
        const card = createForecastCard(day);
        forecastContainer.appendChild(card);
    });

    forecastSection.classList.remove('hidden');
}

/**
 * Create a forecast card element
 */
function createForecastCard(forecast) {
    const card = document.createElement('div');
    card.className = 'forecast-card';

    const date = new Date(forecast.date);
    const dateStr = date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
    });
    const timeStr = date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true
    });

    const iconUrl = `https://openweathermap.org/img/wn/${forecast.icon}@2x.png`;

    card.innerHTML = `
        <div class="forecast-date">${dateStr}</div>
        <div style="font-size: 0.9em; color: #999; margin-bottom: 8px;">${timeStr}</div>
        <img src="${iconUrl}" alt="Weather icon" class="forecast-icon">
        <div class="forecast-desc">${forecast.description}</div>
        <div class="forecast-temps">
            ${Math.round(forecast.temp_min)}° / ${Math.round(forecast.temp_max)}°
        </div>
        <div class="forecast-label">
            💧 ${forecast.humidity}% | 💨 ${forecast.wind_speed.toFixed(1)} m/s
        </div>
    `;

    return card;
}

/**
 * Show loading spinner
 */
function showLoading(show) {
    if (show) {
        loadingSpinner.classList.remove('hidden');
    } else {
        loadingSpinner.classList.add('hidden');
    }
}

/**
 * Show error message
 */
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
}

/**
 * Hide error message
 */
function hideError() {
    errorMessage.classList.remove('show');
    errorMessage.textContent = '';
}

/**
 * Update background based on weather condition
 */
function updateBackgroundBasedOnWeather(iconCode) {
    const container = document.querySelector('.container');
    
    // Determine background based on weather condition
    if (iconCode.includes('d')) { // Day
        if (iconCode.startsWith('01')) {
            // Clear sky
            container.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        } else if (iconCode.startsWith('02') || iconCode.startsWith('03') || iconCode.startsWith('04')) {
            // Clouds
            container.style.background = 'linear-gradient(135deg, #a8a8a8 0%, #5d5d5d 100%)';
        } else {
            // Rain
            container.style.background = 'linear-gradient(135deg, #4a5568 0%, #2d3748 100%)';
        }
    } else { // Night
        container.style.background = 'linear-gradient(135deg, #1a202c 0%, #2d3748 100%)';
    }
}

/**
 * Add some interactivity with keyboard shortcuts
 * Press 'Ctrl+K' to focus on search input
 */
document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        cityInput.focus();
    }
});
