import base64
import os
import uuid
from datetime import datetime

import cv2
import numpy as np
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)
from werkzeug.utils import secure_filename

try:
    from textblob import TextBlob
except Exception:
    TextBlob = None


BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
app.config["SECRET_KEY"] = "ai-sentiment-emotion-analyzer"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

FACE_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)
SMILE_CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_smile.xml")
EYE_CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")

FER_DETECTOR = None
FER_LOAD_ATTEMPTED = False
LAST_FACE_ACTIVITY_AT = None

EMOTIONS = ["Happy", "Sad", "Angry", "Fear", "Surprise", "Neutral"]
SENTIMENTS = ["Positive", "Negative", "Neutral"]

APP_STATS = {
    "text_analyses": 0,
    "face_detections": 0,
    "image_uploads": 0,
    "sentiment_counts": {name: 0 for name in SENTIMENTS},
    "emotion_counts": {name: 0 for name in EMOTIONS},
    "recent_activity": [],
}

EMOTION_LEXICON = {
    "Happy": {
        "happy",
        "joy",
        "joyful",
        "excited",
        "love",
        "great",
        "awesome",
        "amazing",
        "good",
        "wonderful",
        "delight",
        "grateful",
        "smile",
    },
    "Sad": {
        "sad",
        "unhappy",
        "down",
        "cry",
        "lonely",
        "hurt",
        "bad",
        "upset",
        "depressed",
        "disappointed",
        "sorry",
    },
    "Angry": {
        "angry",
        "mad",
        "furious",
        "hate",
        "annoyed",
        "frustrated",
        "rage",
        "irritated",
        "awful",
    },
    "Fear": {
        "fear",
        "scared",
        "afraid",
        "worried",
        "nervous",
        "anxious",
        "panic",
        "terrified",
    },
    "Surprise": {
        "surprise",
        "surprised",
        "shocked",
        "wow",
        "unexpected",
        "sudden",
        "astonished",
    },
    "Neutral": {"okay", "fine", "normal", "average", "regular", "standard"},
}

POSITIVE_WORDS = {
    "good",
    "great",
    "excellent",
    "amazing",
    "awesome",
    "love",
    "happy",
    "success",
    "win",
    "beautiful",
    "best",
    "positive",
    "enjoy",
}
NEGATIVE_WORDS = {
    "bad",
    "terrible",
    "awful",
    "hate",
    "sad",
    "angry",
    "fail",
    "failed",
    "worst",
    "negative",
    "pain",
    "problem",
    "anxious",
}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def now_label():
    return datetime.now().strftime("%b %d, %Y %I:%M %p")


def add_activity(activity_type, title, detail):
    APP_STATS["recent_activity"].insert(
        0,
        {
            "type": activity_type,
            "title": title,
            "detail": detail,
            "timestamp": now_label(),
        },
    )
    APP_STATS["recent_activity"] = APP_STATS["recent_activity"][:10]


def sentiment_icon(sentiment):
    return {"Positive": "😊", "Negative": "😔", "Neutral": "😐"}.get(sentiment, "😐")


def get_fer_detector():
    global FER_DETECTOR, FER_LOAD_ATTEMPTED
    if FER_LOAD_ATTEMPTED:
        return FER_DETECTOR

    FER_LOAD_ATTEMPTED = True
    try:
        from fer import FER

        FER_DETECTOR = FER(mtcnn=False)
    except Exception:
        FER_DETECTOR = None
    return FER_DETECTOR


def fallback_sentiment(text):
    words = [word.strip(".,!?;:()[]{}\"'").lower() for word in text.split()]
    positive_hits = sum(1 for word in words if word in POSITIVE_WORDS)
    negative_hits = sum(1 for word in words if word in NEGATIVE_WORDS)
    total_hits = positive_hits + negative_hits

    if total_hits == 0:
        return 0.0
    return (positive_hits - negative_hits) / max(total_hits, 1)


def detect_emotion_words(text):
    lowered_words = {
        word.strip(".,!?;:()[]{}\"'").lower() for word in text.split() if word.strip()
    }
    matches = []
    emotion_scores = {emotion: 0 for emotion in EMOTIONS}

    for emotion, words in EMOTION_LEXICON.items():
        found = sorted(lowered_words.intersection(words))
        if found:
            emotion_scores[emotion] += len(found)
            matches.extend({"word": word, "emotion": emotion} for word in found)

    dominant = max(emotion_scores, key=emotion_scores.get)
    if emotion_scores[dominant] == 0:
        dominant = "Neutral"
    return matches[:8], dominant


def suggestion_for(sentiment, dominant_emotion):
    if sentiment == "Positive":
        return (
            "Keep the momentum going. This text carries an optimistic tone, "
            "so it is a good fit for customer wins, testimonials, and upbeat messaging."
        )
    if sentiment == "Negative":
        return (
            "The tone sounds heavy. A helpful response would acknowledge the concern, "
            "use calming language, and offer a clear next step."
        )
    if dominant_emotion in {"Fear", "Sad"}:
        return (
            "The text feels emotionally cautious. Consider adding reassurance, context, "
            "and supportive language before asking for action."
        )
    return (
        "The message is balanced and neutral. You can make it more expressive by adding "
        "a clearer opinion, goal, or call to action."
    )


def analyze_text_content(text):
    polarity = TextBlob(text).sentiment.polarity if TextBlob else fallback_sentiment(text)

    if polarity > 0.12:
        sentiment = "Positive"
        confidence = min(99, int(58 + abs(polarity) * 41))
    elif polarity < -0.12:
        sentiment = "Negative"
        confidence = min(99, int(58 + abs(polarity) * 41))
    else:
        sentiment = "Neutral"
        confidence = max(63, int(92 - abs(polarity) * 100))

    emotion_words, dominant_emotion = detect_emotion_words(text)
    return {
        "sentiment": sentiment,
        "icon": sentiment_icon(sentiment),
        "confidence": confidence,
        "polarity": round(polarity, 3),
        "emotion_words": emotion_words,
        "dominant_emotion": dominant_emotion,
        "suggestion": suggestion_for(sentiment, dominant_emotion),
    }


def normalize_emotion_name(name):
    mapping = {
        "happy": "Happy",
        "sad": "Sad",
        "angry": "Angry",
        "fear": "Fear",
        "surprise": "Surprise",
        "neutral": "Neutral",
        "disgust": "Angry",
    }
    return mapping.get(str(name).lower(), "Neutral")


def heuristic_emotions(gray_roi):
    brightness = float(np.mean(gray_roi)) if gray_roi.size else 120.0
    contrast = float(np.std(gray_roi)) if gray_roi.size else 25.0
    smiles = SMILE_CASCADE.detectMultiScale(
        gray_roi,
        scaleFactor=1.8,
        minNeighbors=18,
        minSize=(22, 22),
    )
    eyes = EYE_CASCADE.detectMultiScale(
        gray_roi,
        scaleFactor=1.15,
        minNeighbors=5,
        minSize=(14, 14),
    )

    scores = {
        "Happy": 0.12,
        "Sad": 0.14,
        "Angry": 0.12,
        "Fear": 0.10,
        "Surprise": 0.12,
        "Neutral": 0.40,
    }

    if len(smiles) > 0:
        scores.update({"Happy": 0.67, "Neutral": 0.15, "Surprise": 0.08})
    elif brightness < 75:
        scores.update({"Sad": 0.42, "Fear": 0.18, "Neutral": 0.24})
    elif contrast > 65:
        scores.update({"Angry": 0.35, "Surprise": 0.24, "Neutral": 0.20})
    elif len(eyes) >= 2 and brightness > 145:
        scores.update({"Surprise": 0.34, "Happy": 0.22, "Neutral": 0.25})

    total = sum(scores.values())
    return {emotion: round((score / total) * 100, 1) for emotion, score in scores.items()}


def analyze_faces(image):
    detector = get_fer_detector()
    detections = []

    if detector is not None:
        try:
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            fer_results = detector.detect_emotions(rgb_image)
            for result in fer_results:
                x, y, w, h = result["box"]
                emotions = {
                    normalize_emotion_name(key): round(float(value) * 100, 1)
                    for key, value in result.get("emotions", {}).items()
                }
                for emotion in EMOTIONS:
                    emotions.setdefault(emotion, 0.0)
                top_emotion = max(emotions, key=emotions.get)
                detections.append(
                    {
                        "box": {"x": int(x), "y": int(y), "w": int(w), "h": int(h)},
                        "emotion": top_emotion,
                        "confidence": round(emotions[top_emotion], 1),
                        "emotions": emotions,
                        "engine": "FER + OpenCV",
                    }
                )
        except Exception:
            detections = []

    if detections:
        return detections

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = FACE_CASCADE.detectMultiScale(
        gray,
        scaleFactor=1.12,
        minNeighbors=5,
        minSize=(60, 60),
    )

    for x, y, w, h in faces:
        roi = gray[y : y + h, x : x + w]
        emotions = heuristic_emotions(roi)
        top_emotion = max(emotions, key=emotions.get)
        detections.append(
            {
                "box": {"x": int(x), "y": int(y), "w": int(w), "h": int(h)},
                "emotion": top_emotion,
                "confidence": emotions[top_emotion],
                "emotions": emotions,
                "engine": "OpenCV heuristic",
            }
        )

    return detections


def record_face_activity(detections):
    global LAST_FACE_ACTIVITY_AT
    if not detections:
        return

    now = datetime.now()
    APP_STATS["face_detections"] += len(detections)
    for detection in detections:
        APP_STATS["emotion_counts"][detection["emotion"]] += 1

    if LAST_FACE_ACTIVITY_AT is None or (now - LAST_FACE_ACTIVITY_AT).seconds >= 10:
        LAST_FACE_ACTIVITY_AT = now
        strongest = detections[0]
        add_activity(
            "Face",
            f"{strongest['emotion']} emotion detected",
            f"{strongest['confidence']}% confidence from live camera",
        )


def draw_detection_result(image, detections):
    output = image.copy()
    for detection in detections:
        box = detection["box"]
        label = f"{detection['emotion']} {detection['confidence']}%"
        x, y, w, h = box["x"], box["y"], box["w"], box["h"]
        cv2.rectangle(output, (x, y), (x + w, y + h), (105, 242, 255), 3)
        cv2.rectangle(output, (x, max(0, y - 34)), (x + min(260, w + 90), y), (120, 58, 255), -1)
        cv2.putText(
            output,
            label,
            (x + 8, max(22, y - 10)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.72,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
    return output


def dashboard_payload():
    sentiment_counts = APP_STATS["sentiment_counts"]
    emotion_counts = APP_STATS["emotion_counts"]
    sentiment_values = [sentiment_counts[name] for name in SENTIMENTS]
    emotion_values = [emotion_counts[name] for name in EMOTIONS]

    chart_sentiments = sentiment_values if sum(sentiment_values) else [1, 1, 1]
    chart_emotions = emotion_values if sum(emotion_values) else [1, 1, 1, 1, 1, 1]

    total_sentiment = max(sum(sentiment_values), 1)
    ratio = {
        name: round((sentiment_counts[name] / total_sentiment) * 100)
        for name in SENTIMENTS
    }

    dominant_sentiment = max(sentiment_counts, key=sentiment_counts.get)
    dominant_emotion = max(emotion_counts, key=emotion_counts.get)

    if sum(sentiment_values) == 0 and sum(emotion_values) == 0:
        summary_lines = [
            "Run your first analysis to unlock live AI insights.",
            "Dashboard charts will update as text, webcam, and image results arrive.",
        ]
    else:
        summary_lines = [
            f"Most users showed {dominant_sentiment.lower()} sentiment today {sentiment_icon(dominant_sentiment)}",
            f"{dominant_emotion} emotion is currently dominant.",
        ]

    return {
        "cards": {
            "text_analyses": APP_STATS["text_analyses"],
            "face_detections": APP_STATS["face_detections"],
            "image_uploads": APP_STATS["image_uploads"],
            "ratio": ratio,
        },
        "chart_data": {
            "sentiment_labels": SENTIMENTS,
            "sentiment_values": chart_sentiments,
            "emotion_labels": EMOTIONS,
            "emotion_values": chart_emotions,
        },
        "recent_activity": APP_STATS["recent_activity"],
        "summary_lines": summary_lines,
    }


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/dashboard")
def dashboard():
    payload = dashboard_payload()
    return render_template(
        "dashboard.html",
        cards=payload["cards"],
        chart_data=payload["chart_data"],
        recent_activity=payload["recent_activity"],
        summary_lines=payload["summary_lines"],
    )


@app.route("/text", methods=["GET", "POST"])
def text_analyzer():
    result = None
    error = None
    text_value = ""

    if request.method == "POST":
        text_value = request.form.get("text", "").strip()
        if not text_value:
            error = "Please enter text before running the analyzer."
        else:
            result = analyze_text_content(text_value)
            APP_STATS["text_analyses"] += 1
            APP_STATS["sentiment_counts"][result["sentiment"]] += 1
            APP_STATS["emotion_counts"][result["dominant_emotion"]] += 1
            preview = text_value[:80] + ("..." if len(text_value) > 80 else "")
            add_activity(
                "Text",
                f"{result['sentiment']} sentiment analyzed",
                preview,
            )

    return render_template("text.html", result=result, error=error, text_value=text_value)


@app.route("/face")
def face_detector():
    return render_template("face.html", emotions=EMOTIONS)


@app.route("/api/detect_frame", methods=["POST"])
def detect_frame():
    data = request.get_json(silent=True) or {}
    image_data = data.get("image", "")

    if "," in image_data:
        image_data = image_data.split(",", 1)[1]

    try:
        frame_bytes = base64.b64decode(image_data)
        np_buffer = np.frombuffer(frame_bytes, dtype=np.uint8)
        frame = cv2.imdecode(np_buffer, cv2.IMREAD_COLOR)
    except Exception:
        frame = None

    if frame is None:
        return jsonify({"error": "Unable to read webcam frame."}), 400

    detections = analyze_faces(frame)
    record_face_activity(detections)

    return jsonify(
        {
            "width": int(frame.shape[1]),
            "height": int(frame.shape[0]),
            "face_count": len(detections),
            "detections": detections,
        }
    )


@app.route("/upload", methods=["GET", "POST"])
def upload_image():
    result = None
    error = None

    if request.method == "POST":
        file = request.files.get("image")
        if not file or file.filename == "":
            error = "Choose an image before starting emotion detection."
        elif not allowed_file(file.filename):
            error = "Supported image formats are PNG, JPG, JPEG, and WEBP."
        else:
            original_name = secure_filename(file.filename)
            extension = original_name.rsplit(".", 1)[1].lower()
            stored_name = f"{uuid.uuid4().hex}.{extension}"
            stored_path = os.path.join(app.config["UPLOAD_FOLDER"], stored_name)
            file.save(stored_path)

            image = cv2.imread(stored_path)
            if image is None:
                error = "The image could not be processed. Try another file."
            else:
                detections = analyze_faces(image)
                output = draw_detection_result(image, detections)
                result_name = f"result_{uuid.uuid4().hex}.png"
                result_path = os.path.join(app.config["UPLOAD_FOLDER"], result_name)
                cv2.imwrite(result_path, output)

                top = detections[0] if detections else None
                if top:
                    APP_STATS["emotion_counts"][top["emotion"]] += 1
                    emotion = top["emotion"]
                    confidence = top["confidence"]
                    engine = top["engine"]
                else:
                    emotion = "Neutral"
                    confidence = 0
                    engine = "OpenCV"

                APP_STATS["image_uploads"] += 1
                add_activity(
                    "Image",
                    f"{emotion} emotion detected",
                    f"{original_name} processed with {confidence}% confidence",
                )

                result = {
                    "original_url": url_for("static", filename=f"uploads/{stored_name}"),
                    "result_url": url_for("static", filename=f"uploads/{result_name}"),
                    "download_url": url_for("download_file", filename=result_name),
                    "emotion": emotion,
                    "confidence": confidence,
                    "face_count": len(detections),
                    "engine": engine,
                }

    return render_template("upload.html", result=result, error=error)


@app.route("/download/<path:filename>")
def download_file(filename):
    safe_name = secure_filename(filename)
    return send_from_directory(app.config["UPLOAD_FOLDER"], safe_name, as_attachment=True)


@app.route("/about")
def about():
    return render_template("about.html")


@app.errorhandler(413)
def file_too_large(_error):
    return redirect(url_for("upload_image"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("index.html", error_message="Page not found."), 404


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
