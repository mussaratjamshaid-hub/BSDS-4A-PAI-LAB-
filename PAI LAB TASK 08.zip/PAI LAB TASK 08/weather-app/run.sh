#!/bin/bash

echo "===================================="
echo "Weather App - Setup & Run"
echo "===================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo "Please install Python from https://www.python.org/"
    exit 1
fi

echo "Installing dependencies..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies"
    exit 1
fi

echo ""
echo "Dependency installation complete!"
echo ""
echo "Starting Weather App on http://localhost:5000"
echo "Press Ctrl+C to stop the server"
echo ""

python3 app.py
