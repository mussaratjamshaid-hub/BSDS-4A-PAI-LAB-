from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Simple rule-based response map for university admission info.
responses = {
    "admission requirements": (
        "Admission requirements typically include a completed application, official transcripts, "
        "personal statement, letters of recommendation, and proof of English proficiency if required. "
        "Specific requirements vary by program and degree level."
    ),
    "deadlines": (
        "Application deadlines depend on the term and program. For most undergraduate applicants, "
        "early decision deadlines are in November and regular decision deadlines are in January. "
        "Graduate deadlines often fall between December and March. Check the program page for exact dates."
    ),
    "program info": (
        "We offer programs in Computer Science, Business Administration, Engineering, Biology, "
        "Psychology, and more. Each program includes detailed course plans, faculty highlights, "
        "career outcomes, and internship opportunities."
    ),
    "computer science": (
        "The Computer Science program emphasizes software development, algorithms, data science, "
        "and artificial intelligence. Students can pursue concentrations in cybersecurity, machine learning, "
        "and game development."
    ),
    "business": (
        "The Business Administration program covers finance, marketing, management, and entrepreneurship. "
        "Students complete projects with industry partners and access a strong alumni network."
    ),
    "scholarships": (
        "Scholarships are available for high-achieving students, first-generation college students, "
        "and those with leadership experience. Visit the financial aid page to explore eligibility and apply."
    ),
    "international students": (
        "International applicants must submit academic transcripts, proof of English proficiency, "
        "passport information, and visa support documents. We also provide orientation and support services."
    ),
}

fallback_response = (
    "Hello! I can answer questions about admission requirements, deadlines, program info, "
    "scholarships, and international student guidance. Try asking about admission requirements or program details."
)

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").strip().lower()
    if not user_message:
        return jsonify({"reply": "Please enter a question so I can help you with admissions information."})

    # Match by keyword presence.
    for keyword, response in responses.items():
        if keyword in user_message:
            return jsonify({"reply": response})

    return jsonify({
        "reply": (
            "I couldn't find an exact answer, but I can help with admission requirements, deadlines, "
            "program info, scholarships, or international student guidance. Please ask another question."
        )
    })

if __name__ == "__main__":
    app.run(debug=True)
