# Weather App 🌤️

A beautiful, dynamic weather application built with Flask and vanilla JavaScript. Get real-time weather information and 5-day forecasts for any city in the world.

## Features

✨ **Real-time Weather Data**
- Current temperature, humidity, wind speed, and pressure
- Min/Max temperatures for the day
- Sunrise and sunset times
- Cloud coverage percentage
- Location coordinates (latitude/longitude)

📊 **5-Day Weather Forecast**
- Hourly forecasts for the next 5 days
- Temperature trends
- Weather conditions and icons
- Humidity and wind speed information

🎨 **Dynamic & Responsive Design**
- Beautiful gradient backgrounds that change based on weather
- Fully responsive layout (mobile, tablet, desktop)
- Smooth animations and transitions
- Interactive forecast cards
- Real-time weather icons

⚡ **Fast & Responsive**
- AJAX calls for seamless data loading
- No page reloads needed
- Loading spinner feedback
- Error handling with user-friendly messages

🔍 **Search Functionality**
- Search by city name
- Auto-complete suggestions
- Keyboard shortcuts (Ctrl+K to focus search)
- Enter key support

## Tech Stack

**Backend:**
- Flask 2.3.3
- Python 3.x
- OpenWeatherMap API (Free Tier)

**Frontend:**
- HTML5
- CSS3 (with Flexbox & Grid)
- Vanilla JavaScript (ES6+)
- No external JS libraries

## Installation & Setup

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 2: Run the Application

```bash
python app.py
```

The application will start on `http://localhost:5000`

### Step 3: Open in Browser

Open your web browser and navigate to:
```
http://localhost:5000
```

## Project Structure

```
weather-app/
├── app.py                 # Flask backend (main application)
├── requirements.txt       # Python dependencies
├── templates/
│   └── index.html        # Main HTML template
└── static/
    ├── style.css         # CSS styling
    └── script.js         # JavaScript (dynamic functionality)
```

## API Endpoints

### Get Current Weather
```
GET /api/weather?city=London
```

Returns current weather data including:
- Temperature
- Feels like temperature
- Min/Max temperatures
- Humidity
- Pressure
- Wind speed
- Cloud coverage
- Sunrise/Sunset times
- Weather description and icon
- Coordinates (latitude, longitude)

### Get 5-Day Forecast
```
GET /api/forecast?city=London
```

Returns:
- City name and country
- 5-day forecast (one reading per day)
- Temperature ranges
- Weather conditions
- Humidity and wind speed

## Features Explained

### Dynamic Background
The background gradient changes based on weather conditions:
- **Clear Day:** Blue to Purple
- **Cloudy:** Gray
- **Rainy:** Dark Gray
- **Night:** Dark Blue/Black

### Responsive Design
The app adapts perfectly to:
- 📱 Mobile (480px and below)
- 📱 Tablet (480px - 768px)
- 🖥️ Desktop (768px and above)

### Weather Icons
Real-time weather icons from OpenWeatherMap API that match current conditions visually.

## Shortcuts

- **Ctrl+K (or Cmd+K on Mac):** Focus on the search input
- **Enter:** Search for weather

## Error Handling

- City not found message
- Network error handling
- User-friendly error messages
- Loading states during data fetching

## Future Enhancements

Possible improvements:
- Add more cities to favorites
- Weather alerts and notifications
- Historical weather data
- Weather maps integration
- Multiple language support
- Weather comparison between cities
- Air quality information
- UV index data
- Geolocation-based weather
- Dark/Light theme toggle

## Weather Data Source

This application uses the **OpenWeatherMap API** (Free Tier):
- https://openweathermap.org/api
- No authentication required with the included API key
- Free tier includes current weather and forecasts

## License

This project is open source and available for educational purposes.

## Tips

1. **Search Tips:** Use full city names for best results (e.g., "New York" instead of "NY")
2. **Keyboard Navigation:** Press Ctrl+K to quickly focus on the search box
3. **Favorites:** The app remembers your search history in the JavaScript
4. **Responsive:** Resize your browser to see the responsive design in action

## Troubleshooting

**App won't start:**
- Make sure Python 3.7+ is installed
- Check if port 5000 is available
- Try: `python app.py --port 5001`

**API Errors:**
- Check your internet connection
- Ensure OpenWeatherMap API is reachable
- Check if the city name is spelled correctly

**Display Issues:**
- Clear browser cache
- Try a different browser
- Check browser console for errors (F12)

---

Built with ❤️ using Flask and Vanilla JavaScript
