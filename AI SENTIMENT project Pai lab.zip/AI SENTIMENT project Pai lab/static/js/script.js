(function () {
    const root = document.documentElement;
    const storedTheme = localStorage.getItem("ai-theme") || "dark";
    root.setAttribute("data-theme", storedTheme);

    window.addEventListener("DOMContentLoaded", () => {
        document.body.classList.add("is-ready");
        setupThemeToggle();
        setupMobileMenu();
        setupLoadingForms();
        setupDashboardCharts();
        setupUploadPreview();
        setupCameraDetector();
    });

    function setupThemeToggle() {
        const button = document.querySelector(".theme-toggle");
        const icon = document.querySelector(".theme-icon");
        if (!button) return;

        const syncIcon = () => {
            const theme = root.getAttribute("data-theme");
            if (icon) icon.textContent = theme === "light" ? "☀" : "☾";
        };

        syncIcon();
        button.addEventListener("click", () => {
            const next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
            root.setAttribute("data-theme", next);
            localStorage.setItem("ai-theme", next);
            syncIcon();
        });
    }

    function setupMobileMenu() {
        const nav = document.querySelector(".navbar");
        const toggle = document.querySelector(".menu-toggle");
        if (!nav || !toggle) return;

        toggle.addEventListener("click", () => {
            nav.classList.toggle("menu-open");
        });
    }

    function setupLoadingForms() {
        document.querySelectorAll(".loading-form").forEach((form) => {
            form.addEventListener("submit", () => {
                form.classList.add("is-loading");
                const button = form.querySelector(".form-submit");
                if (button) button.setAttribute("disabled", "disabled");
            });
        });
    }

    function setupDashboardCharts() {
        const dataNode = document.getElementById("dashboard-data");
        const sentimentCanvas = document.getElementById("sentimentChart");
        const emotionCanvas = document.getElementById("emotionChart");
        if (!dataNode || !sentimentCanvas || !emotionCanvas) return;

        if (typeof Chart === "undefined") {
            const fallback = document.getElementById("chartFallback");
            if (fallback) {
                fallback.textContent = "Chart.js could not load. Check your internet connection and refresh.";
            }
            return;
        }

        const chartData = JSON.parse(dataNode.textContent);
        const gridColor = getComputedStyle(document.documentElement)
            .getPropertyValue("--border")
            .trim() || "rgba(255,255,255,0.18)";
        const textColor = getComputedStyle(document.documentElement)
            .getPropertyValue("--text")
            .trim() || "#ffffff";
        const palette = ["#58ffa6", "#ff6b8a", "#65f2ff", "#a855f7", "#ffd166", "#4f8dff"];

        new Chart(sentimentCanvas, {
            type: "pie",
            data: {
                labels: chartData.sentiment_labels,
                datasets: [{
                    data: chartData.sentiment_values,
                    backgroundColor: palette.slice(0, 3),
                    borderColor: "rgba(255,255,255,0.45)",
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: textColor,
                            boxWidth: 14,
                            padding: 16
                        }
                    }
                }
            }
        });

        new Chart(emotionCanvas, {
            type: "bar",
            data: {
                labels: chartData.emotion_labels,
                datasets: [{
                    label: "Detections",
                    data: chartData.emotion_values,
                    backgroundColor: palette,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        ticks: { color: textColor },
                        grid: { display: false }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: textColor,
                            precision: 0
                        },
                        grid: { color: gridColor }
                    }
                },
                plugins: {
                    legend: {
                        labels: { color: textColor }
                    }
                }
            }
        });
    }

    function setupUploadPreview() {
        const dropZone = document.getElementById("dropZone");
        const input = document.getElementById("imageInput");
        const preview = document.getElementById("imagePreview");
        if (!dropZone || !input || !preview) return;

        const showPreview = (file) => {
            if (!file || !file.type.startsWith("image/")) return;
            const reader = new FileReader();
            reader.onload = (event) => {
                preview.src = event.target.result;
                dropZone.classList.add("has-preview");
            };
            reader.readAsDataURL(file);
        };

        input.addEventListener("change", () => {
            showPreview(input.files[0]);
        });

        ["dragenter", "dragover"].forEach((eventName) => {
            dropZone.addEventListener(eventName, (event) => {
                event.preventDefault();
                dropZone.classList.add("is-dragging");
            });
        });

        ["dragleave", "drop"].forEach((eventName) => {
            dropZone.addEventListener(eventName, (event) => {
                event.preventDefault();
                dropZone.classList.remove("is-dragging");
            });
        });

        dropZone.addEventListener("drop", (event) => {
            const file = event.dataTransfer.files[0];
            if (!file) return;

            const transfer = new DataTransfer();
            transfer.items.add(file);
            input.files = transfer.files;
            showPreview(file);
        });
    }

    function setupCameraDetector() {
        const video = document.getElementById("cameraVideo");
        const overlay = document.getElementById("overlayCanvas");
        const capture = document.getElementById("captureCanvas");
        const startButton = document.getElementById("startCamera");
        const stopButton = document.getElementById("stopCamera");
        const statusLine = document.getElementById("cameraStatus");
        const placeholder = document.getElementById("cameraPlaceholder");
        const faceCount = document.getElementById("faceCount");
        const engineBadge = document.getElementById("engineBadge");
        const meterList = document.getElementById("emotionMeters");
        if (!video || !overlay || !capture || !startButton || !stopButton) return;

        let stream = null;
        let intervalId = null;
        let busy = false;

        const setStatus = (message) => {
            if (statusLine) statusLine.textContent = message;
        };

        const syncCanvasSize = () => {
            const width = video.videoWidth || 640;
            const height = video.videoHeight || 400;
            overlay.width = width;
            overlay.height = height;
            capture.width = width;
            capture.height = height;
        };

        const clearOverlay = () => {
            const ctx = overlay.getContext("2d");
            ctx.clearRect(0, 0, overlay.width, overlay.height);
        };

        const drawDetections = (payload) => {
            syncCanvasSize();
            const ctx = overlay.getContext("2d");
            ctx.clearRect(0, 0, overlay.width, overlay.height);
            ctx.save();
            ctx.scale(-1, 1);
            ctx.translate(-overlay.width, 0);

            payload.detections.forEach((detection) => {
                const box = detection.box;
                ctx.strokeStyle = "#65f2ff";
                ctx.lineWidth = 4;
                ctx.shadowColor = "#65f2ff";
                ctx.shadowBlur = 12;
                ctx.strokeRect(box.x, box.y, box.w, box.h);

                ctx.shadowBlur = 0;
                ctx.fillStyle = "rgba(120, 58, 255, 0.84)";
                ctx.fillRect(box.x, Math.max(0, box.y - 34), Math.min(245, box.w + 90), 34);
                ctx.fillStyle = "#ffffff";
                ctx.font = "700 18px system-ui, sans-serif";
                ctx.fillText(`${detection.emotion} ${detection.confidence}%`, box.x + 10, Math.max(23, box.y - 11));
            });

            ctx.restore();
        };

        const updateMeters = (detection) => {
            const emotions = detection ? detection.emotions : {};
            if (faceCount) {
                const count = detection ? "1 face tracked" : "0 faces detected";
                faceCount.textContent = count;
            }
            if (engineBadge && detection) {
                engineBadge.textContent = `Engine: ${detection.engine}`;
            }

            if (!meterList) return;
            meterList.querySelectorAll(".meter-row").forEach((row) => {
                const emotion = row.dataset.emotion;
                const value = Math.round(emotions[emotion] || 0);
                const label = row.querySelector("label b");
                const bar = row.querySelector("i");
                if (label) label.textContent = `${value}%`;
                if (bar) bar.style.width = `${value}%`;
            });
        };

        const analyzeFrame = async () => {
            if (!stream || busy || video.readyState < 2) return;
            busy = true;
            try {
                syncCanvasSize();
                const ctx = capture.getContext("2d");
                ctx.drawImage(video, 0, 0, capture.width, capture.height);
                const image = capture.toDataURL("image/jpeg", 0.78);

                const response = await fetch("/api/detect_frame", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ image })
                });
                const payload = await response.json();

                if (!response.ok) {
                    throw new Error(payload.error || "Frame detection failed.");
                }

                drawDetections(payload);
                const firstDetection = payload.detections[0];
                updateMeters(firstDetection);
                const label = payload.face_count === 1 ? "face" : "faces";
                setStatus(`${payload.face_count} ${label} detected. Live AI scan running.`);
            } catch (error) {
                setStatus(error.message || "Detection paused.");
            } finally {
                busy = false;
            }
        };

        startButton.addEventListener("click", async () => {
            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        width: { ideal: 960 },
                        height: { ideal: 600 },
                        facingMode: "user"
                    },
                    audio: false
                });
                video.srcObject = stream;
                if (placeholder) placeholder.classList.add("is-hidden");
                setStatus("Camera started. Initializing live emotion detection...");

                video.onloadedmetadata = () => {
                    syncCanvasSize();
                    clearInterval(intervalId);
                    intervalId = setInterval(analyzeFrame, 950);
                    analyzeFrame();
                };
            } catch (error) {
                setStatus("Camera permission was blocked or no webcam was found.");
            }
        });

        stopButton.addEventListener("click", () => {
            if (intervalId) clearInterval(intervalId);
            intervalId = null;
            busy = false;
            if (stream) {
                stream.getTracks().forEach((track) => track.stop());
            }
            stream = null;
            video.srcObject = null;
            if (placeholder) placeholder.classList.remove("is-hidden");
            clearOverlay();
            updateMeters(null);
            if (engineBadge) engineBadge.textContent = "Engine: OpenCV ready";
            setStatus("Camera stopped.");
        });
    }
})();
