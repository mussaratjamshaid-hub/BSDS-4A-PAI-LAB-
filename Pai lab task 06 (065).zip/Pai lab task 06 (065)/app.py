import os
import math
import numpy as np
from flask import Flask, request, render_template, send_from_directory, redirect, url_for, flash
from werkzeug.utils import secure_filename

try:
    import dlib
    import cv2
except Exception:
    raise RuntimeError('This app requires dlib and opencv-python. See README for install instructions.')

UPLOAD_FOLDER = 'uploads'
ANNOTATED_FOLDER = 'uploads/annotated'
PREDICTOR_PATH = os.environ.get('DLIB_PREDICTOR_PATH', 'shape_predictor_68_face_landmarks.dat')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'dev'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(ANNOTATED_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def euclid(a, b):
    return float(np.linalg.norm(np.array(a) - np.array(b)))

def compute_measurements(shape):
    pts = np.array([[p.x, p.y] for p in shape.parts()])
    left_eye = pts[36:42].mean(axis=0)
    right_eye = pts[42:48].mean(axis=0)
    eye_dist = euclid(left_eye, right_eye)
    nose_tip = pts[33]
    nose_bridge = pts[27]
    nose_length = euclid(nose_bridge, nose_tip)
    mouth_left = pts[48]
    mouth_right = pts[54]
    mouth_width = euclid(mouth_left, mouth_right)
    chin = pts[8]
    face_left = pts[0]
    face_right = pts[16]
    face_width = euclid(face_left, face_right)
    jaw_left = pts[4]
    jaw_right = pts[12]
    jaw_width = euclid(jaw_left, jaw_right)
    measurements = {
        'eye_distance': eye_dist,
        'nose_length': nose_length,
        'mouth_width': mouth_width,
        'jaw_width': jaw_width,
        'face_width': face_width,
    }
    ratios = {k: (v / face_width if face_width > 0 else 0) for k, v in measurements.items()}
    measurements.update({'ratios': ratios})
    return measurements

def profile_from_measurements(ratios):
    e_i = 'E' if ratios['eye_distance'] > 0.35 else 'I'
    s_n = 'N' if ratios['nose_length'] > 0.25 else 'S'
    t_f = 'T' if ratios['mouth_width'] > 0.40 else 'F'
    j_p = 'J' if ratios['jaw_width'] > 0.45 else 'P'
    personality = e_i + s_n + t_f + j_p
    traits = {
        'E/I': 'Extraverted' if e_i == 'E' else 'Introverted',
        'S/N': 'Intuitive' if s_n == 'N' else 'Sensing',
        'T/F': 'Thinking' if t_f == 'T' else 'Feeling',
        'J/P': 'Judging' if j_p == 'J' else 'Perceiving',
    }
    return personality, traits

def annotate_and_profile(image_path, predictor_path=PREDICTOR_PATH):
    detector = dlib.get_frontal_face_detector()
    if not os.path.exists(predictor_path):
        raise FileNotFoundError(f"dlib predictor not found at {predictor_path}")
    predictor = dlib.shape_predictor(predictor_path)
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    dets = detector(gray, 1)
    results = []
    for i, d in enumerate(dets):
        shape = predictor(gray, d)
        meas = compute_measurements(shape)
        personality, traits = profile_from_measurements(meas['ratios'])
        for p in shape.parts():
            cv2.circle(img, (p.x, p.y), 2, (0, 255, 0), -1)
        x, y, w, h = d.left(), d.top(), d.width(), d.height()
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        annotated_name = os.path.join(ANNOTATED_FOLDER, f'annotated_{i}_{os.path.basename(image_path)}')
        cv2.imwrite(annotated_name, img)
        results.append({'measurements': meas, 'personality': personality, 'traits': traits, 'annotated': annotated_name})
    return results

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory('.', filename)

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(url_for('index'))
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(url_for('index'))
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(path)
        try:
            results = annotate_and_profile(path)
        except Exception as e:
            flash(str(e))
            return redirect(url_for('index'))
        if not results:
            flash('No faces detected')
            return redirect(url_for('index'))
        r = results[0]
        annotated_rel = os.path.relpath(r['annotated']).replace('\\', '/')
        return render_template('result.html', measurements=r['measurements'], personality=r['personality'], traits=r['traits'], image_path=annotated_rel)
    flash('Invalid file type')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
