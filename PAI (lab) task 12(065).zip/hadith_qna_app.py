import os
import re
import pandas as pd
import faiss
import numpy as np
from flask import Flask, render_template, request
from sentence_transformers import SentenceTransformer

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "hadith_qna_data.csv")
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
TOP_K = 4

app = Flask(__name__)


def preprocess(text: str) -> str:
    text = (text or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text


def load_dataset():
    df = pd.read_csv(DATA_PATH)
    df["question"] = df["question"].astype(str).map(preprocess)
    df["answer"] = df["answer"].astype(str).map(preprocess)
    return df


def build_index(model, texts):
    embeddings = model.encode(texts, normalize_embeddings=True)
    if embeddings.dtype != np.float32:
        embeddings = embeddings.astype(np.float32)

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    return index


def search(query: str, df: pd.DataFrame, model, index, top_k: int = TOP_K):
    query = preprocess(query)
    if not query:
        return []

    query_embedding = model.encode([query], normalize_embeddings=True).astype(np.float32)
    scores, indices = index.search(query_embedding, top_k)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx < 0 or idx >= len(df):
            continue
        results.append(
            {
                "question": df.iloc[idx]["question"],
                "answer": df.iloc[idx]["answer"],
                "score": float(score),
            }
        )
    return results


df = load_dataset()
model = SentenceTransformer(MODEL_NAME)
index = build_index(model, df["question"].tolist())


@app.route("/", methods=["GET", "POST"])
def home():
    query = ""
    results = []
    if request.method == "POST":
        query = request.form.get("query", "")
        results = search(query, df, model, index)
    return render_template(
        "index.html",
        query=query,
        results=results,
        dataset_size=len(df),
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
