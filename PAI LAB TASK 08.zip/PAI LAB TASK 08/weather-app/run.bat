@echo off
echo ====================================
echo Weather App - Setup & Run
echo ====================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python from https://www.python.org/
    pause
    exit /b 1
)

echo Installing dependencies...
pip install -r requirements.txt

if errorlevel 1 (
    echo Error: Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo Dependency installation complete!
echo.
echo Starting Weather App on http://localhost:5000
echo Press Ctrl+C to stop the server
echo.

python app.py
pause
