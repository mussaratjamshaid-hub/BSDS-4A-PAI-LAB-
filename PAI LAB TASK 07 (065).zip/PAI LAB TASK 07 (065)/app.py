from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import os
from datetime import datetime

weather_app = Flask(__name__, static_folder="static")
CORS(weather_app)

OPENWEATHER_KEY = os.getenv("OPENWEATHER_KEY")


def valid_unit(unit):
    return unit in ["metric", "imperial", "kelvin"]

def response(success=True, data=None, error=None, status=200):
    return jsonify({"success": success, "data": data, "error": error}), status


class OpenWeather:
    BASE = "http://api.openweathermap.org/data/2.5"

    def __init__(self, api_key):
        self.api_key = api_key

    def _fetch(self, endpoint, params):
        params["appid"] = self.api_key
        try:
            res = requests.get(f"{self.BASE}/{endpoint}", params=params, timeout=10)
            res.raise_for_status()
            return res.json()
        except requests.HTTPError as e:
            code = e.response.status_code
            if code == 401:
                raise Exception("Invalid API key. Please verify your OpenWeatherMap credentials.")
            elif code == 404:
                raise Exception("Requested city or coordinates not found.")
            else:
                raise Exception(f"Weather API error: {e}")
        except requests.RequestException as e:
            raise Exception(f"Network issue: {e}")

    def current_by_city(self, city, unit="metric"):
        return self._fetch("weather", {"q": city, "units": unit})

    def current_by_coords(self, lat, lon, unit="metric"):
        return self._fetch("weather", {"lat": lat, "lon": lon, "units": unit})

    def forecast_by_city(self, city, unit="metric"):
        return self._fetch("forecast", {"q": city, "units": unit})


weather_client = OpenWeather(OPENWEATHER_KEY)


@weather_app.route("/", methods=["GET"])
def index():
    return send_from_directory(".", "index.html")


@weather_app.route("/api/health", methods=["GET"])
def health():
    return response(data={"status": "running", "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})


@weather_app.route("/api/weather/current", methods=["GET"])
def current_weather():
    city = request.args.get("city")
    unit = request.args.get("units", "metric")

    if not city:
        return response(success=False, error="City is required", status=400)
    if not valid_unit(unit):
        return response(success=False, error="Units must be metric, imperial, or kelvin", status=400)

    try:
        data = weather_client.current_by_city(city, unit)
        return response(data=data)
    except Exception as e:
        return response(success=False, error=str(e), status=500)


@weather_app.route("/api/weather/coordinates", methods=["GET"])
def coords_weather():
    lat, lon = request.args.get("lat"), request.args.get("lon")
    unit = request.args.get("units", "metric")

    if not lat or not lon:
        return response(success=False, error="Latitude and longitude are required", status=400)

    try:
        lat, lon = float(lat), float(lon)
    except ValueError:
        return response(success=False, error="Coordinates must be numeric", status=400)

    if not valid_unit(unit):
        return response(success=False, error="Units must be metric, imperial, or kelvin", status=400)

    try:
        data = weather_client.current_by_coords(lat, lon, unit)
        return response(data=data)
    except Exception as e:
        return response(success=False, error=str(e), status=500)


@weather_app.route("/api/weather/forecast", methods=["GET"])
def forecast_weather():
    city = request.args.get("city")
    unit = request.args.get("units", "metric")

    if not city:
        return response(success=False, error="City is required", status=400)
    if not valid_unit(unit):
        return response(success=False, error="Units must be metric, imperial, or kelvin", status=400)

    try:
        data = weather_client.forecast_by_city(city, unit)
        return response(data=data)
    except Exception as e:
        return response(success=False, error=str(e), status=500)


@weather_app.errorhandler(404)
def not_found(_):
    return response(success=False, error="Route not found", status=404)

@weather_app.errorhandler(500)
def server_error(_):
    return response(success=False, error="Unexpected server error", status=500)



if __name__ == "__main__":
    weather_app.run(
        host="0.0.0.0",
        port=int(os.getenv("PORT", 5000)),
        debug=os.getenv("DEBUG", "false").lower() == "true"
    )
