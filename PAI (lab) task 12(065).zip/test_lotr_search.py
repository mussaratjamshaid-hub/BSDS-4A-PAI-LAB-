from lotr_qna_app import search, df, model, index
print(search('Who wrote Lord of the Rings?', df, model, index))