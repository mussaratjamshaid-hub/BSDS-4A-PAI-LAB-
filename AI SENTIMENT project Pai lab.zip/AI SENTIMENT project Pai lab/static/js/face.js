let video = document.getElementById('webcam');
let overlay = document.getElementById('overlay');
let startBtn = document.getElementById('startBtn');
let stopBtn = document.getElementById('stopBtn');
let emotionResult = document.getElementById('emotionResult');
let stream = null;

if (startBtn) {
  startBtn.onclick = async function() {
    stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
    overlay.width = video.videoWidth;
    overlay.height = video.videoHeight;
    detectLoop();
  };
}
if (stopBtn) {
  stopBtn.onclick = function() {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      video.srcObject = null;
      emotionResult.textContent = '';
    }
  };
}

function detectLoop() {
  if (!stream) return;
  // Capture frame every 2s
  setTimeout(async () => {
    let canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    let data = canvas.toDataURL('image/jpeg');
    // Send to backend
    let byteString = atob(data.split(',')[1]);
    let byteArray = Array.from(byteString).map(c => c.charCodeAt(0));
    fetch('/api/face', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: byteArray })
    })
    .then(res => res.json())
    .then(res => {
      emotionResult.textContent = `Emotion: ${res.emotion} (${Math.round(res.confidence)}%)`;
    });
    detectLoop();
  }, 2000);
}
