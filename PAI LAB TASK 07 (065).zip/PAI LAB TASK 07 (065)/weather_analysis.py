import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime
import statistics


def parse_input(path):
    try:
        if path == "-":
            raw = sys.stdin.read()
        else:
            with open(path, "r", encoding="utf-8") as f:
                raw = f.read()
        data = json.loads(raw)
    except Exception as e:
        raise ValueError(f"Failed to read/parse JSON input: {e}")

    if "city" not in data or "observations" not in data:
        raise ValueError("JSON must contain 'city' and 'observations' fields")

    obs = []
    for i, item in enumerate(data["observations"]):
        if not isinstance(item, dict):
            raise ValueError(f"Invalid observation at index {i}")
        ts = item.get("timestamp")
        temp = item.get("temp_c")
        if ts is None or temp is None:
            raise ValueError(f"Observation at index {i} missing 'timestamp' or 'temp_c'")
        try:
            ts_parsed = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except Exception:
            raise ValueError(f"Invalid timestamp format at index {i}: {ts}")
        try:
            temp_f = float(temp)
        except Exception:
            raise ValueError(f"Invalid temperature value at index {i}: {temp}")
        obs.append({"timestamp": ts_parsed, "temp_c": temp_f})

    return {"city": data["city"], "observations": obs}


def group_by_day(observations):
    days = defaultdict(list)
    for item in observations:
        date_key = item["timestamp"].date().isoformat()
        days[date_key].append(item["temp_c"])

    daily_avgs = []
    for date in sorted(days.keys()):
        temps = days[date]
        avg = sum(temps) / len(temps)
        daily_avgs.append((date, avg))

    return daily_avgs


def summary_stats(values):
    if not values:
        return None
    mn = min(values)
    mx = max(values)
    mean = statistics.mean(values)
    std = statistics.pstdev(values)
    return {"min": mn, "max": mx, "mean": mean, "std": std}


def detect_trend(daily_avgs, threshold=0.1):
    if len(daily_avgs) < 2:
        return "stable"
    vals = [v for _, v in daily_avgs]
    slope = (vals[-1] - vals[0]) / max(1, (len(vals) - 1))
    if slope > threshold:
        return "rising"
    if slope < -threshold:
        return "falling"
    return "stable"


def predict_next(daily_avgs, k=3):
    if not daily_avgs:
        return None
    vals = [v for _, v in daily_avgs]
    last_k = vals[-k:]
    return sum(last_k) / len(last_k)


def format_float(v):
    return f"{v:.2f}"


def main():
    parser = argparse.ArgumentParser(description="Weather data analysis and simple prediction")
    parser.add_argument("input", help="Path to JSON input file or - for stdin")
    parser.add_argument("-k", type=int, default=3, help="Moving average window for prediction (default 3)")
    parser.add_argument("--threshold", type=float, default=0.1, help="Trend slope threshold per day")
    args = parser.parse_args()

    try:
        data = parse_input(args.input)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    city = data["city"]
    daily = group_by_day(data["observations"])
    daily_dates = [d for d, _ in daily]
    daily_vals = [v for _, v in daily]

    stats = summary_stats(daily_vals)
    trend = detect_trend(daily, threshold=args.threshold)
    pred = predict_next(daily, k=args.k)

    print(f"City: {city}")
    if daily_dates:
        print(f"Period: {daily_dates[0]} to {daily_dates[-1]}")
        print("Daily averages:", [format_float(v) for v in daily_vals], "°C")
    else:
        print("No observations available.")

    if stats:
        print(f"Summary: min={format_float(stats['min'])} °C, max={format_float(stats['max'])} °C, mean={format_float(stats['mean'])} °C, std={format_float(stats['std'])} °C")
    else:
        print("No statistics available.")

    print(f"Trend: {trend}")
    if pred is not None:
        print(f"Predicted next-day temperature (moving avg K={args.k}): {format_float(pred)} °C")


if __name__ == "__main__":
    main()
