import os
from dotenv import load_dotenv

load_dotenv()


class BaseConfig:
    """Shared configuration defaults for the application."""

    SECRET_KEY = os.getenv("SECRET_KEY", "replace-this-in-production")
    DEBUG = os.getenv("FLASK_DEBUG", "false").lower() == "true"

    WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
    RATELIMIT_STORAGE_URL = os.getenv("REDIS_URL", "memory://")
    CORS_ORIGINS = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "*").split(",")]


class DevConfig(BaseConfig):
    """Settings tailored for local development."""
    DEBUG = True


class ProdConfig(BaseConfig):
    """Settings used when running in production."""
    DEBUG = False


class TestConfig(BaseConfig):
    """Settings for running automated tests."""
    TESTING = True
    DEBUG = True


configurations = {
    "development": DevConfig,
    "production": ProdConfig,
    "testing": TestConfig,
    "default": DevConfig,
}
